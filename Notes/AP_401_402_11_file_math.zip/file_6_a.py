#read a file and print each line inverse
#read a file and print each line inverse
with open("friends.txt","r") as f,open("ifriends.txt","w")as fw:
    while True:
        line = f.readline()
        if len(line) == 0:
            break
        #rline = line[-2::-1] 

        line = line.replace("\n","")
        rline = line[::-1]
        
        fw.write(rline+"\n")


