# read a file and remove line with #
#code.txt

with open("code.txt","r") as f,open("code_no_comment.txt","w")as fw:
    while True:
        line = f.readline()
        if len(line) == 0 :
            break
        tline = line.lstrip()
        if tline!= '' and tline[0] != "#" :            
            fw.write(line)




